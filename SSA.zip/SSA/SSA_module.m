function varargout = SSA_module(varargin)
% SSA_MODULE MATLAB code for SSA_module.fig
%      SSA_MODULE, by itself, creates a new SSA_MODULE or raises the existing
%      singleton*.
%
%      H = SSA_MODULE returns the handle to a new SSA_MODULE or the handle to
%      the existing singleton*.
%
%      SSA_MODULE('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in SSA_MODULE.M with the given input arguments.
%
%      SSA_MODULE('Property','Value',...) creates a new SSA_MODULE or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before SSA_module_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to SSA_module_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help SSA_module

% Last Modified by GUIDE v2.5 18-Oct-2019 15:38:16

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @SSA_module_OpeningFcn, ...
                   'gui_OutputFcn',  @SSA_module_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before SSA_module is made visible.
function SSA_module_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to SSA_module (see VARARGIN)

% Choose default command line output for SSA_module
handles.output = hObject;
addpath(genpath(pwd));       % import�⺯��Ŀ¼
%% ����ȫ�ֱ���
setappdata(handles.figure1,'date',0);
setappdata(handles.figure1,'data',0);
setappdata(handles.figure1,'residual',0);
setappdata(handles.figure1,'X',0);
setappdata(handles.figure1,'U',0);
handles.isFilter = 0;
handles.fpath = [];

% Update handles structure
guidata(hObject, handles);

% UIWAIT makes SSA_module wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = SSA_module_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;



function edit4_Callback(hObject, eventdata, handles)
% hObject    handle to edit4 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit4 as text
%        str2double(get(hObject,'String')) returns contents of edit4 as a double


% --- Executes during object creation, after setting all properties.
function edit4_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit4 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in pushbutton2.
function pushbutton2_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
clc;warning off;
date = getappdata(handles.figure1,'date');
residual = getappdata(handles.figure1, 'residual');

[alldata, str, ~] = xlsread('̨վ��Ϣ', 'sheet1');
Longi = alldata(:, 1);Lati = alldata(:, 2);
fpath = handles.fpath;
index = findstr(fpath, '\');
staName = fpath(index(end)+1: end);
staID = find(cellfun(@(x) ~isempty(strfind(staName, x)), str));
staL = Longi(staID);staB = Lati(staID);

%% ��������
[fEQ, pEQ] = uigetfile('*.*', '��ѡ�����Ŀ¼��');
h1 = msgbox('���������У���Ⱥ�...');
radius1 = 200;radius2 = 300;
selectMag1 = 5;selectMag2 = 6;
[eqTime, eqLongi, eqLati, eqMag, eqDepth] = readEQT([pEQ, fEQ]);
Dis = cal_distance(staL, staB, eqLongi, eqLati);
eqTime_index = find(fix(eqTime)>=min(date) & fix(eqTime)<=max(date));
eqMag_index = union(find(Dis<=radius1 & eqMag>=selectMag1),find(Dis<=radius2 & eqMag>=selectMag2));
select_index = intersect(eqTime_index, eqMag_index);
eqDTArr = eqTime(select_index);
eqLongiArr = eqLongi(select_index);
eqLatiArr = eqLati(select_index);
eqMagArr = eqMag(select_index);
close(h1);

%% �쳣��ȡ
if ~isempty(eqDTArr)
    h2 = msgbox('�쳣ʶ���У���Ⱥ�...');
    [R, abnorm_X, abnorm_Y, alamDaysArr, ThresholdArr, successAlamRateArr, timeOccupiedRateArr] = RTT1(date, residual, eqDTArr);
    RmaxValue = max(max(R));
    [angleIndex, alarmDayIndex] = find(R==RmaxValue);
    close(h2);
    if (~isempty(abnorm_X{angleIndex(1)}))
        [R0, flag, predTArr] = GetR0(eqDTArr, abnorm_X, angleIndex, alamDaysArr, alarmDayIndex);
       %% �����ͼ 
        h3 = msgbox('��ͼ�У���Ⱥ�...');
        %* ����Rֵ-��ֵ-ʱ��2Dͼ
        figure;
        set(gcf, 'position', [100, 100, 700, 500], 'color', 'w');
        interpX = linspace(alamDaysArr(1), alamDaysArr(end), 300);
        interpY = linspace(ThresholdArr(1), ThresholdArr(end),300);
        [interpXX, interpYY] = meshgrid(interpX, interpY);
        interpZZ = interp2(alamDaysArr, ThresholdArr, R, interpXX, interpYY, 'spline');
        pcolor(interpXX, interpYY, interpZZ);hold on;
        shading interp;
        plot(alamDaysArr(alarmDayIndex(1)),ThresholdArr(angleIndex(1)),'ko','markerfacecolor','k','markersize',12);hold on;
        xlabel('Ԥ��ʱ�䣨�죩');ylabel('��ֵ (n��STD)');
        caxis([-1,1]);colorbar;colormap(jet);
        set(gca, 'FontSize', 16, 'LineWidth', 1.2);
        title('R-TT���ߣ�Ч��-Ԥ��ʱ��/��ֵ��', 'fontsize', 16, 'fontname', '����');
%         print(gcf,'-dtiff','-r300','Ч�ܼ�����');
        
        %* ����ʱ����������
        figure;
        set(gcf, 'position', [100, 100, 1100, 500], 'color', 'w');
        thresY1 = mean(residual)+ThresholdArr(angleIndex(1))*std(residual);      %* ��ֵ��������
        thresY2 = mean(residual)-ThresholdArr(angleIndex(1))*std(residual);
        myFill(1, thresY1, date, residual, 'b');
        myFill(-1, thresY2, date, residual, 'b');
        plot(date, residual,'-','color',[.7 .7 .7]);hold on;
        plot([date(1), date(end)], ...
            [mean(residual), mean(residual)], 'k-', 'linewidth', 1.1);hold on;  %* ��ֵ��     
        f1 = plot([date(1), date(end)], [thresY1, thresY1], 'b--');hold on;     
        plot([date(1), date(end)], [thresY2, thresY2], 'b--');hold on;
        ylim([min(residual)-.2*range(residual), max(residual)+.2*range(residual)]);
        ax = gca;
        yL = ax.YTick;
        
        %%% ��Ԥ��ʱ�� && �쳣����
        fid_alarm = fopen('result.txt', 'w');
        fprintf(fid_alarm, '%s\r\n', 'start_Time start_End');
        for jj = 1:length(predTArr)
            if predTArr{jj}(end)>date(end)
                predTArr{jj} = predTArr{jj}(1):date(end);
            end
            data_index = find(ismember(date, predTArr{jj}));
            if length(data_index)<length(predTArr{jj})
                predT_index = find(ismember(predTArr{jj},date));
                predTArr{jj} = predTArr{jj}(predT_index);
            end
            alarm_date = predTArr{jj};
            f2 = plot([alarm_date(1),alarm_date(end)], [yL(1)+0.03*range(yL), yL(1)+0.03*range(yL)], ...
                'r-','LineWidth',7);hold on;
            fprintf(fid_alarm, '%s\r\n', [datestr(predTArr{jj}(1), 'yyyymmdd') ,32, datestr(predTArr{jj}(end), 'yyyymmdd')]);
        end
        fclose(fid_alarm);
        %%% �����
        for i = 1:length(eqDTArr)
            temp_index = find(fix(date)==fix(eqDTArr(i)));
            if flag(i)
                myColor = 'y';
            else
                myColor = [.7 .7 .7];
            end
            plot([eqDTArr(i), eqDTArr(i)], ...
                [yL(1), yL(1)+0.1*range(yL)],'k--');hold on;
            f3 = plot(eqDTArr(i), yL(1)+0.1*range(yL), 'kp', 'markerfacecolor', myColor, 'markersize', 14);hold on;
        end
        
        legend([f1,f2,f3],'��ֵ��','Ԥ��ʱ��','����','location','best');
        xlabel(strcat('ѡȡ��ֵ��', num2str(ThresholdArr(angleIndex(1))),'��STD��'));
        ylabel('�в�ʱ������');
        set(gca,'FontSize',18,'LineWidth',1.2);
        title(strcat('R=',num2str(RmaxValue, 3),...
            '   R0=',num2str(R0, 3),32,32, '���Ԥ��ʱ�䣺',num2str(alamDaysArr(alarmDayIndex(1))),'��'),'fontsize',18,'color','r','fontname','����');
        datetick('x',10);box off;
        xlim([date(1),date(end)]);
        
        %* ���������ռ�ֲ�ͼ
        drawEqDis(staL, staB, eqLongiArr, eqLatiArr, flag, radius1, radius2);
%         print(gcf,'-dtiff','-r300','�����ռ�ֲ�');
        close(h3);
    else
        msgbox('���쳣��RTT������ֹ��');
    end
else
    msgbox('��������RTT������ֹ��');
end


function edit5_Callback(hObject, eventdata, handles)
% hObject    handle to edit5 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit5 as text
%        str2double(get(hObject,'String')) returns contents of edit5 as a double


% --- Executes during object creation, after setting all properties.
function edit5_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit5 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit3_Callback(hObject, eventdata, handles)
% hObject    handle to edit3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit3 as text
%        str2double(get(hObject,'String')) returns contents of edit3 as a double


% --- Executes during object creation, after setting all properties.
function edit3_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
set(hObject, 'String', '365');


% --- Executes on button press in radiobutton1.
function radiobutton1_Callback(hObject, eventdata, handles)
% hObject    handle to radiobutton1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of radiobutton1
flag = get(handles.radiobutton1, 'Value');
if flag
    handles.isFilter = 1;
else
    handles.isFilter = 0;
end
guidata(hObject, handles);



% --- Executes on button press in pushbutton1.
function pushbutton1_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
fpath = handles.fpath;
if isempty(fpath)
    return;
end
[date, data] = readData(fpath);
L = str2num(get(handles.edit3, 'String'));
isFilter = handles.isFilter;
if isFilter
%     data = data - bandpassFilter(data);
    data = data - bandpassFilter2(data);
    
end
%% ���㲿��
% Step 1: �����ͺ����X��L��K��
N = length(data);      % ���ݳ���
if L>N/2
    L = N - L;
end
K = N - L + 1;
X = zeros(L, K);
for i = 1:K
    X(1:L, i) = data(i:L+i-1);
end
% Step 2: SVD��singular value decomposition ����ֵ�ֽ⣩
S = X * X';
[U, autoval] = eig(S);
[d,index] = sort(-diag(autoval));
d = -d; 
U = U(:, index);                % d����ֵ���ɴ�С���У���U��������
sev = sum(d);

setappdata(handles.figure1,'date',date);
setappdata(handles.figure1,'data',data);
setappdata(handles.figure1,'X',X);
setappdata(handles.figure1,'U',U);

axes(handles.axes2);
cla reset;
loglog((d./sev) * 100);hold on;
loglog((d./sev) * 100, 'r*');
title('Singular Spectrum');
xlabel('Eigenvalue Number');
ylabel('Eigenvalue');

% --- Executes on button press in pushbutton3.
function pushbutton3_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
[f, p] = uigetfile('*.*','�������ļ�');
fpath = fullfile(p, f);
set(handles.edit4, 'String', fpath);
handles.fpath = fpath;
[date, data] = readData(fpath);
figure;
set(gcf, 'position', [100, 100, 1100, 500], 'color', 'w');
plot(date, data, 'k-', 'linewidth', 1.1);hold on;
% plot(date, bandpassFilter(data), 'b--');hold on;
axisSetting(24);box off; grid on;
xlabel('���ڣ���/�£�');ylabel('�۲�ֵ��ms��');
title('ˮ��ˮƽ��NS����');
set(gca, 'fontsize', 18);
xlim([date(1)-180,date(end)+180]);
% print(gcf,'-dtiff','-r300','ԭʼ�۲�����');
guidata(hObject, handles);


% --- Executes on button press in pushbutton4.
function pushbutton4_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton4 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
try
    I = str2num(get(handles.edit5, 'String'));
catch
    I = [];
end
date = getappdata(handles.figure1,'date');
data = getappdata(handles.figure1,'data');
X = getappdata(handles.figure1,'X');
U = getappdata(handles.figure1,'U');
N = length(data);
L = str2num(get(handles.edit3, 'String'));
K = N - L + 1;
if ~isempty(I)
    % Step 3: Grouping�����飩
    V = (X') * U;                    % U(:,I)Ϊʱ�侭������������TEOF��
    Vt = V';
    rca = U(:, I)*Vt(I, :);          % ���Ⱦ���ϳɹ켣����L*K��
    
    % Step 4: Reconstruction���ع����У�
    y = zeros(N, 1);
    Lp = min(L, K);
    Kp = max(L, K);
    for k = 0:Lp-2
        for m = 1:k+1
            y(k+1) = y(k+1)+(1/(k+1))*rca(m, k-m+2);
        end
    end
    for k = Lp-1:Kp-1
        for m = 1:Lp
            y(k+1) = y(k+1) + (1/(Lp)) * rca(m, k-m+2);
        end
    end
    for k = Kp:N
        for m = k-Kp+2:N-Kp+1
            y(k+1) = y(k+1)+(1/(N-k))*rca(m,k-m+2);
        end
    end
   
    axes(handles.axes4);cla reset;
%     figure;
%     set(gcf, 'position', [100, 100, 1100, 500], 'color', 'w');
    f1 = plot(date, data, 'color', [.6 .6 .6], 'linewidth', 1.5);hold on;               % ԭʼʱ������
    f2 = plot(date, y, 'b--', 'linewidth', 1.2);grid on;                                % ������ʱ������
    ylim([min(y)-.3*range(y), max(y)+.5*range(y)]);
    legend([f1, f2], {'ȥ����ʱ������', '����ʱ������'}, 'fontsize', 12);
    ylabel('�۲�ֵ��ms��');xlabel('����');
    title('SSA�ع����');
    axisSetting(12);grid on;box off;
    xlim([date(1)-180,date(end)+180]);
%     print(gcf,'-dtiff','-r300','ԭʼ����_�ع�����');
    
    axes(handles.axes6);cla reset;
    r = data - y;
    plot(date, r, 'g');grid on;
    ylim([min(r)-.4*range(r), max(r)+.4*range(r)]);
    axisSetting(9);box off;
    xlabel('ʱ��');ylabel('�в�ʱ������');
    
    setappdata(handles.figure1, 'residual', r);
    % vr = (sum(d(I))/sev) * 100;
    
     axes(handles.axes3);
     cla reset;
     Fs=1/(60 * 60 * 24);               % ����Ƶ�ʣ��վ�ֵ������
     T = 1/Fs;                        % �����������λ���룩
     NFFT = 2^nextpow2(N);
     Y = fft(y, NFFT)/N;
     f_x = Fs/2*linspace(0, 1, NFFT/2+1);
     semilogx(f_x, 2*abs(Y(1:NFFT/2+1)), 'r');hold on;
     [~, index] = max(2*abs(Y(1:NFFT/2+1)));
     title(['The Preferred Period is ', num2str(fix(1/f_x(index)*Fs)), ' days']);
     xlabel('Frequency��Hz��');ylabel('fft��ֵ');
end

% --- Executes during object creation, after setting all properties.
function pushbutton4_CreateFcn(hObject, eventdata, handles)
% hObject    handle to pushbutton4 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called




% --- Executes on button press in pushbutton5.
function pushbutton5_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton5 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
close(handles.figure1);
